import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { amount, recipientName, recipientEmail, buyerName, buyerEmail, message, templateId } = await req.json();

    if (!amount || amount < 50) {
      return new Response(
        JSON.stringify({ error: "Amount must be at least €50" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    if (!recipientName || !recipientEmail || !buyerName || !buyerEmail) {
      return new Response(
        JSON.stringify({ error: "All fields are required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const code = `GC-${Date.now()}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    const barcode = `${Date.now()}${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`;
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);

    const { data: giftCard, error: dbError } = await supabase
      .from("gift_cards")
      .insert({
        code,
        barcode,
        original_amount: amount,
        current_balance: amount,
        recipient_name: recipientName,
        recipient_email: recipientEmail,
        purchaser_name: buyerName,
        purchaser_email: buyerEmail,
        message: message || "",
        template_id: templateId || null,
        status: "active",
        purchase_date: new Date().toISOString(),
        expiry_date: expiryDate.toISOString(),
      })
      .select()
      .single();

    if (dbError) {
      console.error("Database error:", dbError);
      return new Response(
        JSON.stringify({ error: "Failed to create gift card" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    
    if (!stripeKey) {
      return new Response(
        JSON.stringify({ 
          error: "Stripe is not configured. Please contact administrator.",
          giftCardId: giftCard.id 
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const stripeResponse = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${stripeKey}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        "mode": "payment",
        "success_url": req.headers.get("origin") + "/gift-card-success?session_id={CHECKOUT_SESSION_ID}&gift_card_id=" + giftCard.id,
        "cancel_url": req.headers.get("origin") + "/gift-card-widget",
        "line_items[0][price_data][currency]": "eur",
        "line_items[0][price_data][product_data][name]": "Gift Card - " + code,
        "line_items[0][price_data][product_data][description]": "Gift card for " + recipientName,
        "line_items[0][price_data][unit_amount]": String(Math.round(amount * 100)),
        "line_items[0][quantity]": "1",
        "metadata[gift_card_id]": giftCard.id,
        "metadata[code]": code,
        "metadata[barcode]": barcode,
        "customer_email": buyerEmail,
      }),
    });

    if (!stripeResponse.ok) {
      const error = await stripeResponse.text();
      console.error("Stripe error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to create payment session" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const session = await stripeResponse.json();

    await supabase
      .from("gift_cards")
      .update({ stripe_payment_intent_id: session.id })
      .eq("id", giftCard.id);

    return new Response(
      JSON.stringify({
        success: true,
        checkoutUrl: session.url,
        giftCardId: giftCard.id,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});