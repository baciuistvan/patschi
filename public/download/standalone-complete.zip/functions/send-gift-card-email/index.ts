import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { giftCardId } = await req.json();

    if (!giftCardId) {
      return new Response(
        JSON.stringify({ error: "Gift card ID is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: giftCard, error: fetchError } = await supabase
      .from("gift_cards")
      .select("*")
      .eq("id", giftCardId)
      .single();

    if (fetchError || !giftCard) {
      return new Response(
        JSON.stringify({ error: "Gift card not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const expiryDate = new Date(giftCard.expiry_date).toLocaleDateString();
    
    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
          .gift-card { background: white; border: 2px solid #10b981; border-radius: 10px; padding: 30px; margin: 20px 0; text-align: center; }
          .code { font-size: 24px; font-weight: bold; color: #10b981; letter-spacing: 2px; padding: 15px; background: #f0fdf4; border-radius: 5px; margin: 15px 0; }
          .amount { font-size: 36px; font-weight: bold; color: #059669; margin: 15px 0; }
          .details { background: white; padding: 20px; border-radius: 10px; margin: 20px 0; }
          .footer { text-align: center; color: #6b7280; font-size: 12px; margin-top: 30px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎁 Gift Card</h1>
            <p>You've received a gift card!</p>
          </div>
          <div class="content">
            <p>Dear ${giftCard.recipient_name},</p>
            <p>Great news! ${giftCard.purchaser_name} has sent you a gift card!</p>
            
            ${giftCard.message ? `<div class="details"><p><strong>Personal Message:</strong></p><p><em>"${giftCard.message}"</em></p></div>` : ''}
            
            <div class="gift-card">
              <h2>Your Gift Card</h2>
              <div class="amount">€${parseFloat(giftCard.current_balance).toFixed(2)}</div>
              <div class="code">${giftCard.code}</div>
              <p style="color: #6b7280; margin-top: 15px;">Valid until ${expiryDate}</p>
            </div>
            
            <div class="details">
              <h3>How to Use Your Gift Card:</h3>
              <ol>
                <li>Present this gift card code at checkout</li>
                <li>The amount will be deducted from your purchase</li>
                <li>Any remaining balance stays on your card</li>
              </ol>
              <p><strong>Important:</strong> Keep this code safe! Treat it like cash.</p>
            </div>
            
            <div class="footer">
              <p>This gift card expires on ${expiryDate}</p>
              <p>If you have any questions, please contact us.</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;

    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    
    if (!resendApiKey) {
      console.log("Email preview (Resend not configured):");
      console.log(emailHtml);
      return new Response(
        JSON.stringify({ 
          success: true,
          message: "Email would be sent (Resend not configured)",
          preview: emailHtml
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Gift Cards <giftcards@yourdomain.com>",
        to: [giftCard.recipient_email],
        subject: `Gift Card from ${giftCard.purchaser_name} - €${giftCard.current_balance}`,
        html: emailHtml,
      }),
    });

    if (!emailResponse.ok) {
      const error = await emailResponse.text();
      console.error("Email error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to send email" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({ success: true, message: "Email sent successfully" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});