import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { giftCardId } = await req.json();

    if (!giftCardId) {
      return new Response(
        JSON.stringify({ error: "Gift card ID is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: giftCard, error: fetchError } = await supabase
      .from("gift_cards")
      .select("*")
      .eq("id", giftCardId)
      .single();

    if (fetchError || !giftCard) {
      return new Response(
        JSON.stringify({ error: "Gift card not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const expiryDate = new Date(giftCard.expiry_date).toLocaleDateString();
    
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { 
            font-family: Arial, sans-serif; 
            width: 210mm;
            height: 297mm;
            padding: 20mm;
          }
          .gift-card {
            width: 170mm;
            height: 100mm;
            margin: 30mm auto;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
          }
          .header { font-size: 32px; font-weight: bold; margin-bottom: 20px; }
          .amount { 
            font-size: 64px; 
            font-weight: bold; 
            margin: 20px 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
          }
          .code { 
            font-size: 28px; 
            font-weight: bold; 
            letter-spacing: 3px;
            background: rgba(255,255,255,0.2);
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
          }
          .details { 
            font-size: 14px; 
            margin-top: 15px;
            opacity: 0.9;
          }
          .recipient { 
            font-size: 18px;
            margin: 15px 0;
          }
          .message {
            background: rgba(255,255,255,0.15);
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            font-style: italic;
            font-size: 14px;
          }
          .footer {
            position: absolute;
            bottom: 20px;
            left: 30px;
            right: 30px;
            font-size: 12px;
            opacity: 0.8;
          }
        </style>
      </head>
      <body>
        <div class="gift-card">
          <div class="header">🎁 GIFT CARD</div>
          <div class="recipient">For: ${giftCard.recipient_name}</div>
          ${giftCard.message ? `<div class="message">"${giftCard.message}"</div>` : ''}
          <div class="amount">€${parseFloat(giftCard.current_balance).toFixed(2)}</div>
          <div class="code">${giftCard.code}</div>
          <div class="details">
            From: ${giftCard.purchaser_name}<br>
            Valid until: ${expiryDate}
          </div>
          <div class="footer">
            Treat this card like cash. Present code at checkout to redeem.
          </div>
        </div>
      </body>
      </html>
    `;

    const pdfApiUrl = "https://api.html2pdf.app/v1/generate";
    const pdfApiKey = Deno.env.get("HTML2PDF_API_KEY");

    if (!pdfApiKey) {
      return new Response(
        JSON.stringify({ 
          error: "PDF generation not configured",
          html: htmlContent
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const pdfResponse = await fetch(pdfApiUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${pdfApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        html: htmlContent,
        format: "A4",
        printBackground: true,
      }),
    });

    if (!pdfResponse.ok) {
      return new Response(
        JSON.stringify({ error: "Failed to generate PDF" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const pdfBuffer = await pdfResponse.arrayBuffer();

    return new Response(pdfBuffer, {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="gift-card-${giftCard.code}.pdf"`,
      },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});