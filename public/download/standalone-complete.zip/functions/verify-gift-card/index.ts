import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { barcode } = await req.json();

    if (!barcode) {
      return new Response(
        JSON.stringify({ error: "Barcode is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: giftCard, error: fetchError } = await supabase
      .from("gift_cards")
      .select("*")
      .eq("barcode", barcode)
      .single();

    if (fetchError || !giftCard) {
      return new Response(
        JSON.stringify({ 
          valid: false,
          error: "Gift card not found"
        }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const now = new Date();
    const expiryDate = new Date(giftCard.expiry_date);
    const isExpired = now > expiryDate;
    const isValid = giftCard.status === "active" && !isExpired && parseFloat(giftCard.current_balance) > 0;

    return new Response(
      JSON.stringify({
        valid: isValid,
        giftCard: {
          code: giftCard.code,
          balance: parseFloat(giftCard.current_balance),
          originalAmount: parseFloat(giftCard.original_amount),
          status: giftCard.status,
          expiryDate: giftCard.expiry_date,
          isExpired,
          recipientName: giftCard.recipient_name
        }
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});