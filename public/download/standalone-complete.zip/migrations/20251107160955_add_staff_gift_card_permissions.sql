/*
  # Add Staff Permissions for Gift Card Creation

  1. New Function
    - `is_admin_or_staff()` - Returns true if user is admin or staff member
  
  2. Security Changes
    - Update INSERT policy to allow both admin and staff to create gift cards
    - Update UPDATE policy to allow both admin and staff to update gift cards
    - Update DELETE policy to allow both admin and staff to delete gift cards
  
  3. Notes
    - Staff members can now create and manage gift cards alongside admins
    - Public can still verify gift cards using SELECT policy
*/

-- Create helper function to check if user is admin or staff
CREATE OR REPLACE FUNCTION is_admin_or_staff()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM admin_users
    WHERE id = auth.uid()
    AND role IN ('admin', 'staff')
  );
END;
$$;

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Admins can insert gift cards" ON gift_cards;
DROP POLICY IF EXISTS "Admins can update gift cards" ON gift_cards;
DROP POLICY IF EXISTS "Admins can delete gift cards" ON gift_cards;

-- Create new policies that allow both admin and staff
CREATE POLICY "Admin and staff can insert gift cards"
  ON gift_cards
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin_or_staff());

CREATE POLICY "Admin and staff can update gift cards"
  ON gift_cards
  FOR UPDATE
  TO authenticated
  USING (is_admin_or_staff())
  WITH CHECK (is_admin_or_staff());

CREATE POLICY "Admin and staff can delete gift cards"
  ON gift_cards
  FOR DELETE
  TO authenticated
  USING (is_admin_or_staff());
