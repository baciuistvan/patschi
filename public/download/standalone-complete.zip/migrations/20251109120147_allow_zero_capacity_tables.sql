/*
  # Allow Zero Capacity Tables

  1. Changes
    - Drop the existing `valid_capacity` check constraint on the `tables` table
    - Add a new `valid_capacity` check constraint that allows capacity >= 0
    - This enables creating tables with 0 seats (for display purposes without seat count)

  2. Notes
    - Tables with 0 capacity will only show table number/custom label without seat count
    - This is useful for decorative tables, display areas, or organizational markers on floor plans
*/

-- Drop the old constraint that required capacity > 0
ALTER TABLE tables DROP CONSTRAINT IF EXISTS valid_capacity;

-- Add new constraint that allows capacity >= 0
ALTER TABLE tables ADD CONSTRAINT valid_capacity CHECK (capacity >= 0);
