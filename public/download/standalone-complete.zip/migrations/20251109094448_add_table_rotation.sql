/*
  # Add rotation support to tables

  1. Changes
    - Add rotation column to tables (stores angle in degrees, 0-359)
    - Default rotation is 0 (no rotation)
  
  2. Security
    - No changes to RLS policies
*/

-- Add rotation column
ALTER TABLE tables ADD COLUMN IF NOT EXISTS rotation integer DEFAULT 0;

-- Add constraint to ensure rotation is between 0 and 359 degrees
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage 
    WHERE constraint_name = 'valid_rotation' AND table_name = 'tables'
  ) THEN
    ALTER TABLE tables ADD CONSTRAINT valid_rotation CHECK (rotation >= 0 AND rotation < 360);
  END IF;
END $$;
