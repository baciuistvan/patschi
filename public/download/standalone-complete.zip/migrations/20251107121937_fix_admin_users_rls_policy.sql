/*
  # Fix Admin Users RLS Policy - Remove Infinite Recursion

  ## Problem
  The existing "Admin users can view all admin users" policy causes infinite recursion
  because it queries the same table it's protecting.

  ## Solution
  1. Drop the problematic policy
  2. Create a new policy that allows authenticated users to read their own record
  3. This breaks the recursion loop while maintaining security

  ## Changes
  - Drop: "Admin users can view all admin users" policy
  - Create: "Users can view own admin record" policy (checks auth.uid() directly)
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Admin users can view all admin users" ON admin_users;

-- Create a new policy that doesn't cause recursion
-- Authenticated users can view their own admin_users record
CREATE POLICY "Users can view own admin record"
  ON admin_users FOR SELECT
  TO authenticated
  USING (id = auth.uid());
