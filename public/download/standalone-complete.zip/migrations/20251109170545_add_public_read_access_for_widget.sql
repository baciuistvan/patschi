/*
  # Add Public Read Access for Widget

  1. Changes
    - Add public SELECT policy for rooms table (active rooms only)
    - Add public SELECT policy for tables table (active and bookable tables only)
    - Add public SELECT policy for reservations table (for checking availability)
  
  2. Security
    - Only allows reading active/bookable items
    - No write access for public users
    - Maintains existing admin policies
*/

-- Allow public to read active rooms
CREATE POLICY "Public can view active rooms"
  ON rooms
  FOR SELECT
  TO public
  USING (is_active = true);

-- Allow public to read active and bookable tables
CREATE POLICY "Public can view active bookable tables"
  ON tables
  FOR SELECT
  TO public
  USING (is_active = true AND is_bookable = true);

-- Allow public to read reservations (needed for availability checking)
CREATE POLICY "Public can view confirmed reservations"
  ON reservations
  FOR SELECT
  TO public
  USING (status IN ('pending', 'confirmed'));