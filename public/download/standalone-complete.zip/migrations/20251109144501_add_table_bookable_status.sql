/*
  # Add Table Bookable Status

  1. Changes
    - Add `is_bookable` column to `tables` table
      - boolean field to manually control if a table can be booked from the widget
      - defaults to true (bookable)
      - independent from `is_active` which controls visibility
  
  2. Notes
    - `is_active` = false: Table is hidden from floor plan and not bookable
    - `is_active` = true, `is_bookable` = false: Table visible on floor plan but not bookable
    - `is_active` = true, `is_bookable` = true: Table visible and bookable
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tables' AND column_name = 'is_bookable'
  ) THEN
    ALTER TABLE tables ADD COLUMN is_bookable boolean DEFAULT true;
  END IF;
END $$;
