/*
  # Add Stripe payment toggle setting

  1. Changes
    - Insert default setting for stripe_enabled (enabled by default)
    - This allows admins to disable Stripe payment processing for testing

  2. Security
    - Setting is only accessible to admin users via existing RLS policies
*/

INSERT INTO settings (key, value, description)
VALUES ('stripe_enabled', 'true', 'Enable or disable Stripe payment processing in the reservation widget')
ON CONFLICT (key) DO NOTHING;