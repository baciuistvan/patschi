/*
  # Add halfcircle shape to tables

  1. Changes
    - Drop existing valid_shape constraint
    - Add new valid_shape constraint that includes 'halfcircle' option
  
  2. Security
    - No changes to RLS policies
*/

-- Drop the existing constraint
ALTER TABLE tables DROP CONSTRAINT IF EXISTS valid_shape;

-- Add new constraint with halfcircle included
ALTER TABLE tables ADD CONSTRAINT valid_shape CHECK (shape IN ('rectangle', 'circle', 'square', 'halfcircle'));
