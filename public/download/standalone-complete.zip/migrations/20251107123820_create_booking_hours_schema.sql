/*
  # Create Booking Hours and Capacities Schema

  1. New Tables
    - `booking_hours`
      - `id` (uuid, primary key)
      - `room_id` (uuid, foreign key to rooms) - Which room these hours apply to
      - `day_of_week` (integer) - 0 = Sunday, 1 = Monday, etc.
      - `start_time` (time) - Opening time for bookings
      - `end_time` (time) - Closing time for bookings
      - `booking_interval` (integer) - Booking slot duration in minutes (e.g., 30, 60, 90)
      - `capacity_per_slot` (integer) - Maximum capacity per time slot (used when table plan is disabled)
      - `is_active` (boolean) - Whether this time slot is active
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `booking_hours` table
    - Add policy for public read access (needed for widget)
    - Add policy for authenticated admin users to manage booking hours

  3. Notes
    - When table plan is enabled, capacity is calculated from table sizes
    - When table plan is disabled, capacity_per_slot is used
    - booking_interval determines the available time slots (e.g., every 30 minutes)
*/

CREATE TABLE IF NOT EXISTS booking_hours (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid REFERENCES rooms(id) ON DELETE CASCADE,
  day_of_week integer NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  booking_interval integer NOT NULL DEFAULT 60 CHECK (booking_interval > 0),
  capacity_per_slot integer NOT NULL DEFAULT 50 CHECK (capacity_per_slot > 0),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(room_id, day_of_week, start_time)
);

ALTER TABLE booking_hours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read booking hours"
  ON booking_hours FOR SELECT
  TO public
  USING (is_active = true);

CREATE POLICY "Admins can insert booking hours"
  ON booking_hours FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  );

CREATE POLICY "Admins can update booking hours"
  ON booking_hours FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  );

CREATE POLICY "Admins can delete booking hours"
  ON booking_hours FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  );

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_booking_hours_room_day ON booking_hours(room_id, day_of_week);

-- Insert default booking hours (example: daily 12:00 PM to 11:00 PM)
DO $$
DECLARE
  room_record RECORD;
  day_num integer;
BEGIN
  FOR room_record IN SELECT id FROM rooms LOOP
    FOR day_num IN 0..6 LOOP
      INSERT INTO booking_hours (room_id, day_of_week, start_time, end_time, booking_interval, capacity_per_slot)
      VALUES (room_record.id, day_num, '12:00:00', '23:00:00', 60, 50)
      ON CONFLICT (room_id, day_of_week, start_time) DO NOTHING;
    END LOOP;
  END LOOP;
END $$;
