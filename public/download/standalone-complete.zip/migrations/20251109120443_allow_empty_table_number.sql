/*
  # Allow Empty Table Numbers

  1. Changes
    - Modify the `table_number` column in the `tables` table to allow NULL values
    - This enables creating tables without table numbers (useful for decorative elements)
    - Tables without numbers will only show custom labels or capacity

  2. Notes
    - Tables can now have empty table_number field
    - Display logic already handles empty table numbers by hiding them
    - Custom labels or capacity can still be displayed
*/

-- Allow NULL values for table_number
ALTER TABLE tables ALTER COLUMN table_number DROP NOT NULL;
