/*
  # Create Settings Table

  1. New Tables
    - `settings`
      - `key` (text, primary key) - Setting identifier
      - `value` (text) - Setting value
      - `description` (text, optional) - Human-readable description
      - `updated_at` (timestamptz) - Last update timestamp

  2. Initial Data
    - Insert default deposit amount setting

  3. Security
    - Enable RLS on `settings` table
    - Add policy for anyone to read settings (public data)
    - Add policy for authenticated admin users to update settings
*/

CREATE TABLE IF NOT EXISTS settings (
  key text PRIMARY KEY,
  value text NOT NULL,
  description text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read settings"
  ON settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can update settings"
  ON settings FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  );

CREATE POLICY "Admins can insert settings"
  ON settings FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.email = auth.email()
    )
  );

-- Insert default settings
INSERT INTO settings (key, value, description)
VALUES ('deposit_amount', '20', 'Reservation deposit amount in euros')
ON CONFLICT (key) DO NOTHING;
