/*
  # Add Booking Confirmation Field

  1. Changes
    - Add `require_confirmation` column to `booking_hours` table
      - boolean field to indicate if bookings need admin approval
      - defaults to false (instant confirmation)
  
  2. Notes
    - When true, reservations will be created with 'pending' status
    - When false, reservations will be created with 'confirmed' status
    - This allows flexible booking workflows per time slot
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'booking_hours' AND column_name = 'require_confirmation'
  ) THEN
    ALTER TABLE booking_hours ADD COLUMN require_confirmation boolean DEFAULT false;
  END IF;
END $$;
