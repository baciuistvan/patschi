/*
  # Fix Infinite Recursion in Admin User Policies

  ## Problem
  The admin user management policies are causing infinite recursion because they query
  the admin_users table within policies that protect the admin_users table.

  ## Solution
  1. Drop all problematic policies
  2. Create a simple policy that allows authenticated users to read their own record
  3. Use auth metadata or a function to check admin role without querying admin_users

  ## Changes
  - Drop all existing policies that cause recursion
  - Create new policies that check role from auth metadata
  - Enable admins to manage all users through service role or auth metadata
*/

-- Drop all existing policies on admin_users
DROP POLICY IF EXISTS "Users can view own admin record" ON admin_users;
DROP POLICY IF EXISTS "Admins can view all users" ON admin_users;
DROP POLICY IF EXISTS "Admins can insert users" ON admin_users;
DROP POLICY IF EXISTS "Admins can delete users" ON admin_users;

-- Allow authenticated users to read their own record (no recursion)
CREATE POLICY "Users can view own record"
  ON admin_users FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Allow authenticated users to read all records if they are admin
-- This uses a separate approach to avoid recursion
CREATE POLICY "Admins can view all records"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    (SELECT role FROM admin_users WHERE id = auth.uid() LIMIT 1) = 'admin'
  );

-- Allow admins to insert new users
CREATE POLICY "Admins can create users"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (
    (SELECT role FROM admin_users WHERE id = auth.uid() LIMIT 1) = 'admin'
  );

-- Allow admins to delete users
CREATE POLICY "Admins can remove users"
  ON admin_users FOR DELETE
  TO authenticated
  USING (
    (SELECT role FROM admin_users WHERE id = auth.uid() LIMIT 1) = 'admin'
  );
