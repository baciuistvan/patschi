/*
  # Add custom label support to tables

  1. Changes
    - Add `custom_label` column to `tables` table to support custom text like "BAR"
    - When set, this label will be displayed instead of table number and capacity
  
  2. Notes
    - This allows for special purpose tables like bars, buffets, DJ stations, etc.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tables' AND column_name = 'custom_label'
  ) THEN
    ALTER TABLE tables ADD COLUMN custom_label text;
  END IF;
END $$;