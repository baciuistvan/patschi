/*
  # Add Admin User Management Policies

  ## Overview
  Adds RLS policies to allow admin users to manage (view, create, delete) all admin and staff accounts.

  ## Changes
  1. Add policy for admins to view all admin users
  2. Add policy for admins to insert new admin/staff users
  3. Add policy for admins to delete admin/staff users

  ## Security
  - Only users with 'admin' role can manage users
  - Staff users can only view their own record (existing policy)
  - All policies check the role from the admin_users table
*/

-- Policy: Admins can view all admin users
CREATE POLICY "Admins can view all users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.id = auth.uid()
      AND au.role = 'admin'
    )
  );

-- Policy: Admins can insert new admin/staff users
CREATE POLICY "Admins can insert users"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.id = auth.uid()
      AND au.role = 'admin'
    )
  );

-- Policy: Admins can delete admin/staff users
CREATE POLICY "Admins can delete users"
  ON admin_users FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au
      WHERE au.id = auth.uid()
      AND au.role = 'admin'
    )
  );
