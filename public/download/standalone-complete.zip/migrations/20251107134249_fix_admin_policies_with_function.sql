/*
  # Fix Admin Policies with Security Definer Function

  ## Problem
  RLS policies that query the same table they protect cause infinite recursion.

  ## Solution
  Create a SECURITY DEFINER function that bypasses RLS to check if a user is an admin.
  Then use this function in the RLS policies.

  ## Changes
  1. Create is_admin() function with SECURITY DEFINER
  2. Update all policies to use this function instead of querying admin_users directly
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own record" ON admin_users;
DROP POLICY IF EXISTS "Admins can view all records" ON admin_users;
DROP POLICY IF EXISTS "Admins can create users" ON admin_users;
DROP POLICY IF EXISTS "Admins can remove users" ON admin_users;

-- Create a security definer function to check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM admin_users
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$;

-- Policy: Users can view their own record
CREATE POLICY "Users can view own record"
  ON admin_users FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Policy: Admins can view all users
CREATE POLICY "Admins can view all users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (is_admin());

-- Policy: Admins can insert new users
CREATE POLICY "Admins can insert users"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

-- Policy: Admins can delete users
CREATE POLICY "Admins can delete users"
  ON admin_users FOR DELETE
  TO authenticated
  USING (is_admin());
