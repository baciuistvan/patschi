import{Q as t,j as e,R as o,K as r}from"./index-BOzEqeXg.js";t.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(r,{})}));
